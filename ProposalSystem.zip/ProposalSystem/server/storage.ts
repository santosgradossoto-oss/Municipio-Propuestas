import { type Proposal, type InsertProposal } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Proposals
  getAllProposals(): Promise<Proposal[]>;
  getProposal(id: string): Promise<Proposal | undefined>;
  createProposal(proposal: InsertProposal): Promise<Proposal>;
  voteProposal(id: string): Promise<Proposal | undefined>;
  unvoteProposal(id: string): Promise<Proposal | undefined>;
}

export class MemStorage implements IStorage {
  private proposals: Map<string, Proposal>;

  constructor() {
    this.proposals = new Map();
  }

  async getAllProposals(): Promise<Proposal[]> {
    return Array.from(this.proposals.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getProposal(id: string): Promise<Proposal | undefined> {
    return this.proposals.get(id);
  }

  async createProposal(insertProposal: InsertProposal): Promise<Proposal> {
    const id = randomUUID();
    const proposal: Proposal = {
      ...insertProposal,
      id,
      votes: 0,
      createdAt: new Date(),
    };
    this.proposals.set(id, proposal);
    return proposal;
  }

  async voteProposal(id: string): Promise<Proposal | undefined> {
    const proposal = this.proposals.get(id);
    if (!proposal) {
      return undefined;
    }

    const updatedProposal: Proposal = {
      ...proposal,
      votes: proposal.votes + 1,
    };

    this.proposals.set(id, updatedProposal);
    return updatedProposal;
  }

  async unvoteProposal(id: string): Promise<Proposal | undefined> {
    const proposal = this.proposals.get(id);
    if (!proposal) {
      return undefined;
    }

    const updatedProposal: Proposal = {
      ...proposal,
      votes: Math.max(0, proposal.votes - 1),
    };

    this.proposals.set(id, updatedProposal);
    return updatedProposal;
  }
}

export const storage = new MemStorage();
