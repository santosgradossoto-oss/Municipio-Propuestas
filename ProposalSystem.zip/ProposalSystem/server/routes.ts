import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProposalSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // GET /api/proposals - Obtener todas las propuestas
  app.get("/api/proposals", async (req, res) => {
    try {
      const proposals = await storage.getAllProposals();
      res.json(proposals);
    } catch (error) {
      console.error("Error fetching proposals:", error);
      res.status(500).json({ error: "Error al obtener las propuestas" });
    }
  });

  // POST /api/proposals - Crear nueva propuesta
  app.post("/api/proposals", async (req, res) => {
    try {
      const validation = insertProposalSchema.safeParse(req.body);
      
      if (!validation.success) {
        const errorMessage = fromZodError(validation.error).toString();
        return res.status(400).json({ error: errorMessage });
      }

      const proposal = await storage.createProposal(validation.data);
      res.status(201).json(proposal);
    } catch (error) {
      console.error("Error creating proposal:", error);
      res.status(500).json({ error: "Error al crear la propuesta" });
    }
  });

  // POST /api/proposals/:id/vote - Votar por una propuesta
  app.post("/api/proposals/:id/vote", async (req, res) => {
    try {
      const { id } = req.params;
      const proposal = await storage.voteProposal(id);

      if (!proposal) {
        return res.status(404).json({ error: "Propuesta no encontrada" });
      }

      res.json(proposal);
    } catch (error) {
      console.error("Error voting proposal:", error);
      res.status(500).json({ error: "Error al votar la propuesta" });
    }
  });

  // DELETE /api/proposals/:id/vote - Quitar voto de una propuesta
  app.delete("/api/proposals/:id/vote", async (req, res) => {
    try {
      const { id } = req.params;
      const proposal = await storage.unvoteProposal(id);

      if (!proposal) {
        return res.status(404).json({ error: "Propuesta no encontrada" });
      }

      res.json(proposal);
    } catch (error) {
      console.error("Error unvoting proposal:", error);
      res.status(500).json({ error: "Error al quitar el voto" });
    }
  });

  // GET /api/stats - Obtener estadísticas de la plataforma
  app.get("/api/stats", async (req, res) => {
    try {
      const proposals = await storage.getAllProposals();
      
      const totalProposals = proposals.length;
      const totalVotes = proposals.reduce((sum, p) => sum + p.votes, 0);
      
      // Encontrar la categoría más popular
      const categoryCount = proposals.reduce((acc, p) => {
        acc[p.category] = (acc[p.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const topCategoryEntry = Object.entries(categoryCount).sort((a, b) => b[1] - a[1])[0];
      
      const stats = {
        totalProposals,
        totalVotes,
        topCategory: topCategoryEntry?.[0] || "N/A",
        topCategoryCount: topCategoryEntry?.[1] || 0,
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: "Error al obtener estadísticas" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
