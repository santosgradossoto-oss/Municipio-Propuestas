import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Categorías disponibles para las propuestas
export const CATEGORIES = [
  "Educación",
  "Infraestructura",
  "Medio Ambiente",
  "Salud",
  "Deporte",
  "Tecnología",
  "Cultura",
  "Seguridad"
] as const;

export type Category = typeof CATEGORIES[number];

// Tabla de propuestas estudiantiles
export const proposals = pgTable("proposals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  votes: integer("votes").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Schema de validación para crear propuestas
export const insertProposalSchema = createInsertSchema(proposals).omit({
  id: true,
  votes: true,
  createdAt: true,
}).extend({
  title: z.string().min(5, "El título debe tener al menos 5 caracteres").max(100, "El título no puede exceder 100 caracteres"),
  description: z.string().min(20, "La descripción debe tener al menos 20 caracteres").max(500, "La descripción no puede exceder 500 caracteres"),
  category: z.enum(CATEGORIES, { 
    errorMap: () => ({ message: "Debes seleccionar una categoría válida" })
  }),
});

export type InsertProposal = z.infer<typeof insertProposalSchema>;
export type Proposal = typeof proposals.$inferSelect;

// Tipos para estadísticas
export interface Stats {
  totalProposals: number;
  totalVotes: number;
  topCategory: string;
  topCategoryCount: number;
}

// Tipos para ordenamiento
export type SortOption = "recent" | "votes" | "alphabetical";
