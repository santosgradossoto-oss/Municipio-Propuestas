import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, TrendingUp, FileText, Award } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ProposalCard } from "@/components/ProposalCard";
import { ProposalForm } from "@/components/ProposalForm";
import { StatsPanel } from "@/components/StatsPanel";
import { EmptyState } from "@/components/EmptyState";
import { CATEGORIES, type Category, type SortOption, type Proposal } from "@shared/schema";
import heroImage from "@assets/generated_images/Students_collaborating_in_classroom_aad7839c.png";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<Category | "all">("all");
  const [sortBy, setSortBy] = useState<SortOption>("recent");
  const [showCreateForm, setShowCreateForm] = useState(false);

  // Fetch proposals
  const { data: proposals = [], isLoading } = useQuery<Proposal[]>({
    queryKey: ["/api/proposals"],
  });

  // Filter and sort proposals
  const filteredProposals = proposals
    .filter((proposal) => {
      const matchesSearch =
        searchQuery === "" ||
        proposal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proposal.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory =
        selectedCategory === "all" || proposal.category === selectedCategory;
      
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === "votes") return b.votes - a.votes;
      if (sortBy === "alphabetical") return a.title.localeCompare(b.title);
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative min-h-[500px] md:min-h-[600px] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6 lg:px-8 text-center text-white py-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">
            Tu Voz Cuenta
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto text-white/95 drop-shadow">
            Comparte tus ideas y vota por las mejores propuestas para mejorar nuestro municipio escolar
          </p>
          <Button
            size="lg"
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg"
            data-testid="button-create-proposal-hero"
          >
            <FileText className="w-5 h-5 mr-2" />
            {showCreateForm ? "Ver Propuestas" : "Crear Nueva Propuesta"}
          </Button>

          {/* Stats Bar */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl mx-auto">
            <div className="backdrop-blur-md bg-white/10 rounded-lg p-4 border border-white/20">
              <div className="text-3xl font-bold">{proposals.length}</div>
              <div className="text-sm text-white/90">Propuestas Activas</div>
            </div>
            <div className="backdrop-blur-md bg-white/10 rounded-lg p-4 border border-white/20">
              <div className="text-3xl font-bold">
                {proposals.reduce((sum, p) => sum + p.votes, 0)}
              </div>
              <div className="text-sm text-white/90">Votos Totales</div>
            </div>
            <div className="backdrop-blur-md bg-white/10 rounded-lg p-4 border border-white/20">
              <div className="text-3xl font-bold">{CATEGORIES.length}</div>
              <div className="text-sm text-white/90">Categorías</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-12">
        {/* Stats Panel */}
        <StatsPanel />

        {/* Create Form */}
        {showCreateForm && (
          <div className="mb-12">
            <ProposalForm onSuccess={() => setShowCreateForm(false)} />
          </div>
        )}

        {/* Search and Filter Bar */}
        <div className="sticky top-0 z-20 bg-background/95 backdrop-blur-sm border-b border-border py-4 mb-8 -mx-4 px-4 md:-mx-6 md:px-6 lg:-mx-8 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar propuestas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>

            {/* Category Filter */}
            <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
              <Button
                variant={selectedCategory === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory("all")}
                className="whitespace-nowrap"
                data-testid="button-category-all"
              >
                Todas
              </Button>
              {CATEGORIES.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="whitespace-nowrap"
                  data-testid={`button-category-${category.toLowerCase()}`}
                >
                  {category}
                </Button>
              ))}
            </div>

            {/* Sort Dropdown */}
            <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
              <SelectTrigger className="w-full md:w-[200px]" data-testid="select-sort">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Más Recientes</SelectItem>
                <SelectItem value="votes">Más Votadas</SelectItem>
                <SelectItem value="alphabetical">Alfabético</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Proposals Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-card rounded-lg p-6 space-y-4 border border-card-border">
                  <div className="h-6 bg-muted rounded w-1/3" />
                  <div className="h-8 bg-muted rounded w-3/4" />
                  <div className="space-y-2">
                    <div className="h-4 bg-muted rounded" />
                    <div className="h-4 bg-muted rounded w-5/6" />
                  </div>
                  <div className="h-10 bg-muted rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredProposals.length === 0 ? (
          <EmptyState 
            hasSearchOrFilter={searchQuery !== "" || selectedCategory !== "all"}
            onReset={() => {
              setSearchQuery("");
              setSelectedCategory("all");
            }}
            onCreateNew={() => setShowCreateForm(true)}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProposals.map((proposal) => (
              <ProposalCard key={proposal.id} proposal={proposal} />
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-card border-t border-card-border mt-20">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-semibold text-lg mb-4">Sobre la Plataforma</h3>
              <p className="text-sm text-muted-foreground">
                Una plataforma diseñada para fomentar la participación estudiantil y hacer que cada voz cuente en las decisiones del municipio escolar.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">Enlaces Rápidos</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Cómo Funciona</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Categorías</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Preguntas Frecuentes</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">Contacto</h3>
              <p className="text-sm text-muted-foreground mb-4">
                ¿Tienes preguntas o sugerencias?
              </p>
              <div className="flex gap-2">
                <Input 
                  type="email" 
                  placeholder="Tu email" 
                  className="text-sm"
                  data-testid="input-newsletter"
                />
                <Button size="sm" data-testid="button-newsletter">
                  Suscribir
                </Button>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
            <p>&copy; 2025 Propuestas Estudiantiles. Impulsando la participación activa.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
