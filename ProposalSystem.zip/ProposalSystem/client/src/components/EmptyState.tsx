import { FileQuestion, Search, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface EmptyStateProps {
  hasSearchOrFilter: boolean;
  onReset: () => void;
  onCreateNew: () => void;
}

export function EmptyState({ hasSearchOrFilter, onReset, onCreateNew }: EmptyStateProps) {
  if (hasSearchOrFilter) {
    return (
      <Card className="border-dashed border-2 border-card-border">
        <CardContent className="flex flex-col items-center justify-center py-16 px-4">
          <div className="bg-muted/50 p-4 rounded-full mb-4">
            <Search className="w-12 h-12 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold mb-2">No se encontraron propuestas</h3>
          <p className="text-muted-foreground text-center max-w-md mb-6">
            No hay propuestas que coincidan con tu búsqueda o filtros. Intenta con otros términos o categorías.
          </p>
          <Button onClick={onReset} variant="outline" data-testid="button-reset-filters">
            Limpiar Filtros
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-dashed border-2 border-card-border">
      <CardContent className="flex flex-col items-center justify-center py-16 px-4">
        <div className="bg-primary/10 p-4 rounded-full mb-4">
          <FileQuestion className="w-12 h-12 text-primary" />
        </div>
        <h3 className="text-xl font-semibold mb-2">Aún no hay propuestas</h3>
        <p className="text-muted-foreground text-center max-w-md mb-6">
          Sé el primero en compartir una idea para mejorar nuestro municipio escolar. ¡Tu voz es importante!
        </p>
        <Button onClick={onCreateNew} size="lg" data-testid="button-create-first">
          <Plus className="w-5 h-5 mr-2" />
          Crear Primera Propuesta
        </Button>
      </CardContent>
    </Card>
  );
}
