import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { ThumbsUp, Calendar } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Proposal } from "@shared/schema";
import { 
  AcademicCapIcon, 
  BuildingOfficeIcon, 
  GlobeAmericasIcon, 
  HeartIcon,
  TrophyIcon,
  ComputerDesktopIcon,
  MusicalNoteIcon,
  ShieldCheckIcon
} from "@heroicons/react/24/outline";

// Mapeo de iconos para cada categoría
const categoryIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  "Educación": AcademicCapIcon,
  "Infraestructura": BuildingOfficeIcon,
  "Medio Ambiente": GlobeAmericasIcon,
  "Salud": HeartIcon,
  "Deporte": TrophyIcon,
  "Tecnología": ComputerDesktopIcon,
  "Cultura": MusicalNoteIcon,
  "Seguridad": ShieldCheckIcon,
};

// Utilidades para gestionar votos en localStorage
const VOTES_STORAGE_KEY = "student_proposals_votes";

function getVotedProposals(): Set<string> {
  try {
    const stored = localStorage.getItem(VOTES_STORAGE_KEY);
    return stored ? new Set(JSON.parse(stored)) : new Set();
  } catch {
    return new Set();
  }
}

function saveVotedProposal(proposalId: string): void {
  const voted = getVotedProposals();
  voted.add(proposalId);
  localStorage.setItem(VOTES_STORAGE_KEY, JSON.stringify(Array.from(voted)));
}

function removeVotedProposal(proposalId: string): void {
  const voted = getVotedProposals();
  voted.delete(proposalId);
  localStorage.setItem(VOTES_STORAGE_KEY, JSON.stringify(Array.from(voted)));
}

interface ProposalCardProps {
  proposal: Proposal;
}

export function ProposalCard({ proposal }: ProposalCardProps) {
  const { toast } = useToast();
  const [hasVoted, setHasVoted] = useState(false);
  
  const Icon = categoryIcons[proposal.category] || AcademicCapIcon;

  // Verificar si el usuario ya votó por esta propuesta al cargar
  useEffect(() => {
    const voted = getVotedProposals();
    setHasVoted(voted.has(proposal.id));
  }, [proposal.id]);

  const voteMutation = useMutation({
    mutationFn: async () => {
      if (hasVoted) {
        await apiRequest("DELETE", `/api/proposals/${proposal.id}/vote`);
      } else {
        await apiRequest("POST", `/api/proposals/${proposal.id}/vote`);
      }
    },
    onSuccess: () => {
      // Actualizar localStorage y estado local
      if (hasVoted) {
        removeVotedProposal(proposal.id);
        setHasVoted(false);
      } else {
        saveVotedProposal(proposal.id);
        setHasVoted(true);
      }
      
      queryClient.invalidateQueries({ queryKey: ["/api/proposals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      
      toast({
        title: hasVoted ? "Voto retirado" : "¡Voto registrado!",
        description: hasVoted 
          ? "Has retirado tu voto de esta propuesta" 
          : "Tu voto ha sido contabilizado exitosamente",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo procesar tu voto. Inténtalo nuevamente.",
        variant: "destructive",
      });
    },
  });

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <Card className="group hover:shadow-md transition-all duration-300 flex flex-col h-full" data-testid={`card-proposal-${proposal.id}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-4">
        <Badge 
          variant="secondary" 
          className="flex items-center gap-1.5 text-xs font-medium"
          data-testid={`badge-category-${proposal.id}`}
        >
          <Icon className="w-3.5 h-3.5" />
          {proposal.category}
        </Badge>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Calendar className="w-3 h-3" />
          <span data-testid={`text-date-${proposal.id}`}>
            {formatDate(proposal.createdAt)}
          </span>
        </div>
      </CardHeader>

      <CardContent className="flex-1 space-y-3">
        <h3 
          className="text-xl font-semibold line-clamp-2 group-hover:text-primary transition-colors"
          data-testid={`text-title-${proposal.id}`}
        >
          {proposal.title}
        </h3>
        <p 
          className="text-sm text-muted-foreground line-clamp-3"
          data-testid={`text-description-${proposal.id}`}
        >
          {proposal.description}
        </p>
      </CardContent>

      <CardFooter className="flex items-center justify-between pt-4 border-t border-card-border">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <ThumbsUp className="w-5 h-5 text-primary" />
            <span 
              className="text-2xl font-bold text-foreground"
              data-testid={`text-votes-${proposal.id}`}
            >
              {proposal.votes}
            </span>
          </div>
          <span className="text-sm text-muted-foreground">
            {proposal.votes === 1 ? "voto" : "votos"}
          </span>
        </div>

        <Button
          size="default"
          variant={hasVoted ? "default" : "outline"}
          onClick={() => voteMutation.mutate()}
          disabled={voteMutation.isPending}
          className="min-w-[100px]"
          data-testid={`button-vote-${proposal.id}`}
        >
          {voteMutation.isPending ? (
            <span>Procesando...</span>
          ) : hasVoted ? (
            <span>Quitar Voto</span>
          ) : (
            <span>Votar</span>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
