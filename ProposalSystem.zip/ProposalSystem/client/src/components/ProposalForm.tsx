import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertProposalSchema, type InsertProposal, CATEGORIES } from "@shared/schema";
import { 
  AcademicCapIcon, 
  BuildingOfficeIcon, 
  GlobeAmericasIcon, 
  HeartIcon,
  TrophyIcon,
  ComputerDesktopIcon,
  MusicalNoteIcon,
  ShieldCheckIcon,
  CheckCircleIcon
} from "@heroicons/react/24/outline";

const categoryIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  "Educación": AcademicCapIcon,
  "Infraestructura": BuildingOfficeIcon,
  "Medio Ambiente": GlobeAmericasIcon,
  "Salud": HeartIcon,
  "Deporte": TrophyIcon,
  "Tecnología": ComputerDesktopIcon,
  "Cultura": MusicalNoteIcon,
  "Seguridad": ShieldCheckIcon,
};

interface ProposalFormProps {
  onSuccess?: () => void;
}

export function ProposalForm({ onSuccess }: ProposalFormProps) {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const form = useForm<InsertProposal>({
    resolver: zodResolver(insertProposalSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "" as any,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertProposal) => {
      return await apiRequest("POST", "/api/proposals", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/proposals"] });
      toast({
        title: "¡Propuesta creada!",
        description: "Tu propuesta ha sido publicada exitosamente",
      });
      form.reset();
      setSelectedCategory(null);
      onSuccess?.();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo crear la propuesta",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertProposal) => {
    createMutation.mutate(data);
  };

  return (
    <Card className="shadow-lg border-card-border">
      <CardHeader>
        <CardTitle className="text-2xl md:text-3xl">Crear Nueva Propuesta</CardTitle>
        <CardDescription>
          Comparte tu idea para mejorar nuestro municipio escolar. Todos pueden votar por las mejores propuestas.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-base font-semibold">
                        Título de la Propuesta *
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Ej: Mejorar la biblioteca escolar"
                          {...field}
                          className="border-2 focus:ring-2 transition-all"
                          data-testid="input-title"
                        />
                      </FormControl>
                      <FormDescription>
                        Un título claro y conciso (5-100 caracteres)
                      </FormDescription>
                      <FormMessage />
                      {field.value.length >= 5 && (
                        <div className="flex items-center gap-1 text-green-600 text-sm">
                          <CheckCircleIcon className="w-4 h-4" />
                          <span>Título válido</span>
                        </div>
                      )}
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-base font-semibold">
                        Descripción *
                      </FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe tu propuesta en detalle. ¿Qué problema soluciona? ¿Cómo beneficiaría a la comunidad estudiantil?"
                          {...field}
                          rows={6}
                          className="border-2 focus:ring-2 transition-all resize-none"
                          data-testid="input-description"
                        />
                      </FormControl>
                      <FormDescription>
                        Explica tu propuesta (20-500 caracteres)
                      </FormDescription>
                      <FormMessage />
                      {field.value.length >= 20 && (
                        <div className="flex items-center gap-1 text-green-600 text-sm">
                          <CheckCircleIcon className="w-4 h-4" />
                          <span>Descripción válida</span>
                        </div>
                      )}
                    </FormItem>
                  )}
                />
              </div>

              {/* Right Column */}
              <div className="space-y-6">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-base font-semibold">
                        Categoría *
                      </FormLabel>
                      <FormDescription className="mb-3">
                        Selecciona la categoría que mejor describe tu propuesta
                      </FormDescription>
                      <FormControl>
                        <div className="grid grid-cols-2 gap-3">
                          {CATEGORIES.map((category) => {
                            const Icon = categoryIcons[category];
                            const isSelected = field.value === category;
                            
                            return (
                              <button
                                key={category}
                                type="button"
                                onClick={() => {
                                  field.onChange(category);
                                  setSelectedCategory(category);
                                }}
                                className={`
                                  flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all
                                  ${isSelected 
                                    ? 'border-primary bg-primary/10 text-primary' 
                                    : 'border-border hover:border-primary/50 hover:bg-accent'
                                  }
                                `}
                                data-testid={`button-category-${category.toLowerCase()}`}
                              >
                                <Icon className="w-8 h-8" />
                                <span className="text-xs font-medium text-center">
                                  {category}
                                </span>
                                {isSelected && (
                                  <CheckCircleIcon className="w-5 h-5 text-primary" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-border">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  form.reset();
                  setSelectedCategory(null);
                }}
                disabled={createMutation.isPending}
                data-testid="button-reset"
              >
                Limpiar
              </Button>
              <Button
                type="submit"
                size="lg"
                disabled={createMutation.isPending || !form.formState.isValid}
                className="min-w-[150px]"
                data-testid="button-submit"
              >
                {createMutation.isPending ? "Creando..." : "Publicar Propuesta"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
