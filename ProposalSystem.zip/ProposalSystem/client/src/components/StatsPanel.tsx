import { useQuery } from "@tanstack/react-query";
import { FileText, TrendingUp, Award } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import type { Stats } from "@shared/schema";

export function StatsPanel() {
  const { data: stats, isLoading, isError } = useQuery<Stats>({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <div className="mb-12">
        <h2 className="text-2xl md:text-3xl font-semibold mb-6 text-center">
          Estadísticas de Participación
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="border-card-border">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="bg-muted rounded-lg p-3 w-12 h-12 animate-pulse" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded w-24 animate-pulse" />
                    <div className="h-8 bg-muted rounded w-16 animate-pulse" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (isError || !stats) {
    return (
      <div className="mb-12">
        <h2 className="text-2xl md:text-3xl font-semibold mb-6 text-center">
          Estadísticas de Participación
        </h2>
        <Card className="border-destructive/50">
          <CardContent className="p-6 text-center">
            <p className="text-destructive">Error al cargar las estadísticas</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statsData = [
    {
      icon: FileText,
      label: "Total de Propuestas",
      value: stats.totalProposals,
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-950/30",
      testId: "stat-proposals"
    },
    {
      icon: TrendingUp,
      label: "Votos Totales",
      value: stats.totalVotes,
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-950/30",
      testId: "stat-votes"
    },
    {
      icon: Award,
      label: "Categoría Popular",
      value: stats.topCategory,
      subtitle: stats.topCategoryCount > 0 ? `${stats.topCategoryCount} propuestas` : "",
      color: "text-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-950/30",
      testId: "stat-category"
    },
  ];

  return (
    <div className="mb-12">
      <h2 className="text-2xl md:text-3xl font-semibold mb-6 text-center">
        Estadísticas de Participación
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {statsData.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="border-card-border" data-testid={stat.testId}>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className={`${stat.bgColor} p-3 rounded-lg`}>
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground mb-1">
                      {stat.label}
                    </p>
                    <p className="text-3xl md:text-4xl font-bold text-foreground">
                      {stat.value}
                    </p>
                    {stat.subtitle && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {stat.subtitle}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
