# Design Guidelines: Plataforma de Propuestas Estudiantiles

## Design Approach

**Selected System:** Material Design-inspired civic platform
**Rationale:** Educational/civic platforms require trust, clarity, and accessibility. Material Design's elevation system and clear hierarchy work perfectly for information-dense voting platforms while maintaining visual interest.

## Typography System

**Font Family:** 
- Primary: Inter (via Google Fonts CDN)
- Headings: 600-700 weight
- Body: 400-500 weight
- Small text/labels: 500 weight

**Type Scale:**
- Hero/Main Heading: text-4xl md:text-5xl font-bold
- Section Headings: text-2xl md:text-3xl font-semibold
- Card Titles: text-xl font-semibold
- Body Text: text-base
- Labels/Meta: text-sm font-medium
- Stats Numbers: text-3xl md:text-4xl font-bold

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 20
- Component padding: p-4 to p-6
- Section spacing: py-12 to py-20
- Card gaps: gap-4 to gap-6
- Element margins: m-2, m-4, m-6

**Container Strategy:**
- Max width: max-w-7xl mx-auto
- Page padding: px-4 md:px-6 lg:px-8
- Content sections: max-w-6xl for optimal reading

## Component Library

### Navigation
- Fixed header with shadow-sm elevation
- Logo left, navigation center/right
- Mobile: Hamburger menu with slide-in drawer
- Height: h-16 with flex items-center
- Links: Subtle hover with underline decoration

### Hero Section
- Height: min-h-[500px] md:min-h-[600px] - NOT full viewport
- Large background image showing engaged students in school setting (diverse group collaborating, bright educational environment)
- Centered content with overlay (bg-black/40)
- Large heading + supporting text + CTA button with backdrop-blur-md bg-white/10
- Stats bar at bottom (proposals submitted, votes cast, active categories) with semi-transparent cards

### Proposal Creation Form
- Card with shadow-md and rounded-lg borders
- Two-column layout on desktop (title/description left, category/submit right)
- Input fields: border-2 with focus:ring-2 focus:border-accent
- Category selector: Grid of 8 category pills (grid-cols-2 md:grid-cols-4)
- Each category with icon from Heroicons + label
- Real-time validation: Green checkmark for valid, red text for errors
- Submit button: Large, prominent, disabled state when invalid

### Proposal Cards
- Grid layout: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Card structure: rounded-lg shadow-sm hover:shadow-md transition
- Top: Category badge (rounded-full px-3 py-1 text-xs)
- Title: text-xl font-semibold with 2-line clamp
- Description: text-sm with 3-line clamp
- Bottom section: Vote count (large number + icon) + Vote button
- Voting button: Icon button with heart/thumbs-up from Heroicons
- Active vote state: Filled icon with subtle scale animation

### Search and Filter Bar
- Sticky position below header (sticky top-16)
- Three sections: Search input | Category filter | Sort dropdown
- Search: Full-width on mobile, w-64 md:w-96 on desktop
- Search icon (Heroicons) left-aligned in input
- Category filter: Horizontal scroll on mobile, flex-wrap on desktop
- Sort: Dropdown with simple arrow indicator

### Statistics Dashboard
- Three-column grid on desktop, single column mobile
- Large stat cards with shadow-lg and gradient backgrounds
- Icon (from Heroicons) + Large number + Label
- Stats: Total Propuestas | Votos Totales | Categoría Popular
- Animated count-up effect on page load (pure CSS)

### Category Indicators
**8 Categories with Icons (Heroicons):**
- Educación: AcademicCapIcon
- Infraestructura: BuildingOfficeIcon
- Medio Ambiente: GlobeAmericasIcon
- Salud: HeartIcon
- Deporte: TrophyIcon
- Tecnología: ComputerDesktopIcon
- Cultura: MusicalNoteIcon
- Seguridad: ShieldCheckIcon

### Empty States
- Centered container with icon + heading + description
- Illustration placeholder or large icon from Heroicons
- Helpful text explaining how to create first proposal or no results

### Footer
- Multi-column layout: About | Quick Links | Contact Info
- Social media icons (Heroicons: Twitter, Facebook, Instagram)
- Copyright and powered-by section
- Email newsletter signup (input + button inline)

## Interactions & Animations

**Minimal Animation Strategy:**
- Card hover: Subtle scale (scale-105) + shadow increase
- Button hover: Slight brightness change
- Vote button: Quick scale pulse on click (scale-110 → scale-100)
- Form validation: Smooth color transitions
- No complex scroll animations or parallax

## Responsive Behavior

**Breakpoints:**
- Mobile: Base (< 768px) - Single column, stacked layout
- Tablet: md (768px+) - Two columns where appropriate
- Desktop: lg (1024px+) - Full three-column grids

**Mobile Optimizations:**
- Larger touch targets (min-h-12)
- Bottom-fixed action buttons for proposal creation
- Simplified navigation with drawer
- Horizontal scrolling for category filters

## Images

**Hero Image:**
- Large hero background image showing diverse students collaborating in a bright, modern school environment
- Subject: 4-6 students of varying backgrounds gathered around a table, looking engaged and discussing ideas
- Setting: Well-lit classroom or common area with modern furniture, possibly with whiteboard/posters in background
- Mood: Energetic, collaborative, inclusive
- Treatment: Slightly desaturated to allow text overlay to stand out
- Position: Cover with center positioning

**Optional Supporting Images:**
- Category cards can have small illustrative icons or photos
- Empty state illustrations (simple, line-art style)

## Accessibility

- All form inputs with proper labels (not just placeholders)
- ARIA labels for icon-only buttons
- Keyboard navigation support for all interactive elements
- Focus indicators with ring-2 ring-offset-2
- Sufficient color contrast ratios (WCAG AA minimum)
- Screen reader friendly vote counts and status messages